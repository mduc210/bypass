// ==UserScript==
// @name         Yeumoney Bypasser by anh hiếu đẹp zai
// @namespace    http://tampermonkey.net/
// @version      10.0
// @description  The Ultimate Yeumoney Bypass Chính thức (Hieudz * Ducknovis * XGreen)
// @author       HieuDz
// @match        *://yeumoney.com/*
// @match        *://docs.google.com/spreadsheets/*
// @match        *://docs.google.com/forms/*
// @grant        GM_xmlhttpRequest
// @require      https://raw.githubusercontent.com/Hieugamingmc747/BypassYeumoney/refs/heads/main/BypassYeumoney.js
// @grant        GM_getValue
// @grant        GM_setValue
// @icon         https://tr.rbxcdn.com/180DAY-433e973b5fbc1e8d5cdebd0c6be03472/420/420/Decal/Webp/noFilter
// ==/UserScript==
